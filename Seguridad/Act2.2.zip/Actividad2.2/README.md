# Requirements

Uses langdetect library to "cut time" (not really) for the deciphering of Ceasar's cypher

# Notes

Brute forces the matching of the most repeated character with the position of the " " character in the base alphabet (but works lmao). Ideally it would rotate through the most likely keys but it was very very likely match the most repeated chars to the " " character, so I left it this way.