import React from "react";
import "./DnDBox.css";
import { useState } from "react";

export default function DnDBox() {
  const [dragActive, setDragActive] = useState(false);

  function uploadFile(file) {
    console.log("File selected: " + file.name);
  }

  function handleDrag(event) {
    event.preventDefault();
    event.stopPropagation();
    if (event.type === "dragenter" || event.type === "dragover") {
      setDragActive(true);
    } else if (event.type === "dragleave") {
      setDragActive(false);
    }
  }

  function handleDrop(event) {
    event.preventDefault();
    event.stopPropagation();
    setDragActive(false);
    if (event.dataTransfer.files && event.dataTransfer.files[0]) {
      const file = event.dataTransfer.files[0];
      uploadFile(file);
    }
  }

  function handleChange(event) {
    event.preventDefault();
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      uploadFile(file);
    }
  }

  function handleSubmit(event) {
    event.preventDefault();
  }

  return (
    <form
      id="form-file-upload"
      onDragEnter={handleDrag}
      onSubmit={handleSubmit}
    >
      <input
        id="input-file-upload"
        type="file"
        accept="application/pdf" //Marca qué tipo aceptar
        onChange={handleChange}
      />
      <label
        id="label-file-upload"
        htmlFor="input-file-upload" //Indica a qué componente de liga
        className={dragActive ? "drag-active" : ""}
      >
        <div>
          <p>Drag PDF file here </p>
          <button className="upload-button">Click here to select files</button>
        </div>
      </label>
      {dragActive && (
        <div
          id="drag-file-element"
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
        ></div>
      )}
    </form>
  );
}
